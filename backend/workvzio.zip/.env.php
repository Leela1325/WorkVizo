<?php

define('SMTP_EMAIL', 'lp8830827@gmail.com');
define('SMTP_APP_PASSWORD', 'tgdkcycdnugyodrn');
