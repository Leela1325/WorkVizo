<?php
require_once __DIR__ . "/vendor/PHPMailer/src/PHPMailer.php";
require_once __DIR__ . "/vendor/PHPMailer/src/SMTP.php";
require_once __DIR__ . "/vendor/PHPMailer/src/Exception.php";

use PHPMailer\PHPMailer\PHPMailer;

echo "PHPMailer loaded successfully";
