<?php
require_once __DIR__ . '/.env.php';

echo SMTP_EMAIL;
