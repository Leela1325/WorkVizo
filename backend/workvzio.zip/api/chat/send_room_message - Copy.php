<?php
echo "CHAT API OK";
