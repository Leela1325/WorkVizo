package com.workvizo.api

import retrofit2.Call
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST

interface ApiService {

    @FormUrlEncoded
    @POST("login.php")
    fun login(
        @Field("email") email: String,
        @Field("password") password: String
    ): Call<LoginResponse>   // ✔ NO SUSPEND

    @FormUrlEncoded
    @POST("auth/register.php")
    fun register(
        @Field("name") name: String,
        @Field("email") email: String,
        @Field("dob") dob: String,
        @Field("password") password: String,
        @Field("createpassword") createpassword: String
    ): Call<RegisterResponse>

}
