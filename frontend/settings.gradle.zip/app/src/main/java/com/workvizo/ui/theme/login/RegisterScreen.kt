package com.workvizo.ui.theme.login

import android.util.Log
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.workvizo.R
import com.workvizo.api.RegisterResponse
import com.workvizo.api.RetrofitClient
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RegisterScreen(navController: NavController) {

    val poppins = FontFamily(Font(R.font.poppins_bold, FontWeight.Bold))

    var fullName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var dob by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }

    var passwordVisible by remember { mutableStateOf(false) }
    var confirmPasswordVisible by remember { mutableStateOf(false) }

    var serverMessage by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }

    // Validation
    val emailError = email.isNotEmpty() &&
            !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()

    val passMismatch = confirmPassword.isNotEmpty() && confirmPassword != password
    val dobValid = dob.matches(Regex("^\\d{2}/\\d{2}/\\d{4}$"))

    val formValid =
        fullName.isNotEmpty() &&
                email.isNotEmpty() &&
                dobValid &&
                password.isNotEmpty() &&
                confirmPassword.isNotEmpty() &&
                !emailError &&
                !passMismatch

    // Gradient background
    val gradient = Brush.linearGradient(
        listOf(
            Color(0xFF0D1B2A),
            Color(0xFF1B263B),
            Color(0xFF283B70),
            Color(0xFF0077B6),
            Color(0xFF00A8E8)
        ),
        start = Offset(0f, 0f),
        end = Offset(1500f, 1800f)
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(gradient)
            .padding(16.dp)
    ) {

        // Top bar
        Row(
            modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                Icons.Default.ArrowBack,
                contentDescription = "Back",
                tint = Color.White,
                modifier = Modifier.size(30.dp).clickable {
                    navController.popBackStack()
                }
            )

            Image(
                painter = painterResource(id = R.drawable.logo),
                contentDescription = "Logo",
                modifier = Modifier
                    .size(45.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .border(1.5.dp, Color.White, RoundedCornerShape(10.dp))
            )
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 70.dp, bottom = 30.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Text("Create Account", color = Color.White, fontFamily = poppins, fontSize = 34.sp)
            Spacer(Modifier.height(10.dp))
            Text(
                "Join WorkVizo today. Start smarter workflows.",
                color = Color.White.copy(alpha = 0.9f),
                fontFamily = poppins,
                fontSize = 14.sp
            )

            Spacer(Modifier.height(28.dp))

            // Form card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White.copy(0.10f), RoundedCornerShape(22.dp))
                    .padding(26.dp)
            ) {

                Column(horizontalAlignment = Alignment.CenterHorizontally) {

                    StyledField("Full Name", fullName, { fullName = it }, Icons.Default.Person, poppins)
                    Spacer(Modifier.height(20.dp))

                    StyledField("Email", email, { email = it }, Icons.Default.Email, poppins, emailError, "Invalid email")
                    Spacer(Modifier.height(20.dp))

                    OutlinedTextField(
                        value = dob,
                        onValueChange = { input ->
                            val digits = input.filter { it.isDigit() }
                            val builder = StringBuilder()

                            for (i in digits.indices) {
                                builder.append(digits[i])
                                if (i == 1 || i == 3) builder.append("/")
                            }

                            dob = builder.take(10).toString()
                        },
                        label = { Text("Date of Birth (DD/MM/YYYY)", fontFamily = poppins, color = Color.White) },
                        leadingIcon = { Icon(Icons.Default.DateRange, null, tint = Color.White) },
                        textStyle = TextStyle(color = Color.White, fontFamily = poppins),
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, Color.White.copy(.35f), RoundedCornerShape(12.dp))
                    )

                    if (!dobValid && dob.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        Text("Enter valid DOB (DD/MM/YYYY)", color = Color.Yellow, fontFamily = poppins, fontSize = 12.sp)
                    }

                    Spacer(Modifier.height(20.dp))

                    StyledPasswordField("Password", password, { password = it }, passwordVisible,
                        { passwordVisible = !passwordVisible }, poppins)

                    Spacer(Modifier.height(20.dp))

                    StyledPasswordField("Confirm Password", confirmPassword, { confirmPassword = it },
                        confirmPasswordVisible, { confirmPasswordVisible = !confirmPasswordVisible },
                        poppins, passMismatch, "Passwords do not match")
                }
            }

            Spacer(Modifier.height(24.dp))

            // Register Button
            Button(
                onClick = {
                    isLoading = true
                    serverMessage = ""

                    val call = RetrofitClient.instance.register(
                        fullName.trim(),
                        email.trim(),
                        dob.trim(),
                        password.trim(),
                        confirmPassword.trim()
                    )

                    call.enqueue(object : Callback<RegisterResponse> {

                        override fun onResponse(
                            call: Call<RegisterResponse>,
                            response: Response<RegisterResponse>
                        ) {
                            isLoading = false

                            Log.d("REGISTER", "Response RAW: ${response.raw()}")
                            Log.d("REGISTER", "Body: ${response.body()}")

                            val body = response.body()

                            if (body?.status == "success") {
                                navController.navigate("onboard")
                            } else {
                                serverMessage = body?.message ?: "Unknown error"
                            }
                        }

                        override fun onFailure(call: Call<RegisterResponse>, t: Throwable) {
                            isLoading = false
                            serverMessage = "Network error: ${t.message}"
                        }
                    })
                },
                enabled = formValid,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (formValid) Color.White else Color.White.copy(0.32f)
                )
            ) {
                Text(
                    "Register",
                    fontFamily = poppins,
                    fontSize = 18.sp,
                    color = if (formValid) Color(0xFF0D1B2A) else Color.Black.copy(0.6f)
                )
            }

            if (serverMessage.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                Text(serverMessage, color = Color.Yellow, fontFamily = poppins, fontSize = 14.sp)
            }
        }
    }

    // 🔥 FULLSCREEN LOADING OVERLAY
    if (isLoading) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.5f)),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(
                color = Color.White,
                strokeWidth = 4.dp
            )
        }
    }
}

/* -------------------------------------
      REUSABLE COMPONENTS
------------------------------------- */

@Composable
fun StyledField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    icon: ImageVector,
    poppins: FontFamily,
    error: Boolean = false,
    errorText: String = ""
) {
    Column {
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            label = { Text(label, fontFamily = poppins, color = Color.White) },
            leadingIcon = { Icon(icon, null, tint = Color.White) },
            textStyle = TextStyle(color = Color.White, fontFamily = poppins),
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color.White.copy(.35f), RoundedCornerShape(12.dp))
        )

        if (error) {
            Spacer(Modifier.height(6.dp))
            Text(errorText, fontFamily = poppins, color = Color.Yellow, fontSize = 12.sp)
        }
    }
}

@Composable
fun StyledPasswordField(
    label: String,
    value: String,
    onValueChange: (String) -> Unit,
    visible: Boolean,
    onToggle: () -> Unit,
    poppins: FontFamily,
    error: Boolean = false,
    errorText: String = ""
) {
    Column {
        OutlinedTextField(
            value = value,
            onValueChange = onValueChange,
            label = { Text(label, fontFamily = poppins, color = Color.White) },
            leadingIcon = { Icon(Icons.Default.Lock, null, tint = Color.White) },
            trailingIcon = {
                Icon(
                    if (visible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                    null,
                    tint = Color.White,
                    modifier = Modifier.clickable { onToggle() }
                )
            },
            visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
            textStyle = TextStyle(color = Color.White, fontFamily = poppins),
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, Color.White.copy(.35f), RoundedCornerShape(12.dp))
        )

        if (error) {
            Spacer(Modifier.height(6.dp))
            Text(errorText, fontFamily = poppins, color = Color.Yellow, fontSize = 12.sp)
        }
    }
}
