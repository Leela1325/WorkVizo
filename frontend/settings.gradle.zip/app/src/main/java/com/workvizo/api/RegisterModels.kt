package com.workvizo.api

data class RegisterResponse(
    val status: String,
    val message: String
)
