package com.workvizo.ui.theme.login

import com.workvizo.api.RetrofitClient
import com.workvizo.api.LoginResponse
import com.workvizo.api.UserData

import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.workvizo.R
import kotlinx.coroutines.launch
import retrofit2.Response


// -------------------------------------------
// DATA MODELS
// -------------------------------------------

data class LoginResponse(
    val status: String,
    val message: String,
    val user: UserData?
)

data class UserData(
    val id: String,
    val name: String,
    val email: String,
    val dob: String
)


// -------------------------------------------
// LOGIN SCREEN
// -------------------------------------------
@Composable
fun LoginScreen(navController: NavController) {

    val poppins = FontFamily(Font(R.font.poppins_bold, FontWeight.Bold))

    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var serverMessage by remember { mutableStateOf("") }

    val coroutineScope = rememberCoroutineScope()

    val emailError = email.isNotEmpty() &&
            !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()

    val passwordError = password.isNotEmpty() && password.length < 6

    val formValid = !emailError && !passwordError && email.isNotEmpty() && password.isNotEmpty()


    // Gradient
    val gradient = Brush.verticalGradient(
        colors = listOf(
            Color(0xFF0D1B2A),
            Color(0xFF1B263B),
            Color(0xFF223A70),
            Color(0xFF00A8E8)
        )
    )


    // Flash animation
    val infiniteTransition = rememberInfiniteTransition()
    val flashOffset by infiniteTransition.animateFloat(
        initialValue = -300f,
        targetValue = 300f,
        animationSpec = infiniteRepeatable(
            tween(1200, easing = LinearEasing),
            RepeatMode.Restart
        )
    )


    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(gradient)
            .padding(horizontal = 22.dp)
    ) {

        // Logo top
        Image(
            painter = painterResource(id = R.drawable.logo),
            contentDescription = "Logo",
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 26.dp)
                .size(55.dp)
                .clip(RoundedCornerShape(10.dp))
                .border(1.5.dp, Color.White, RoundedCornerShape(10.dp))
        )


        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 40.dp)
                .wrapContentHeight(Alignment.CenterVertically),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            // Title
            Text(
                text = "WorkVizo",
                fontSize = 42.sp,
                fontFamily = poppins,
                color = Color.White
            )

            Text(
                text = "Proof-driven tasks. Smarter teamwork.",
                fontSize = 15.sp,
                fontFamily = poppins,
                color = Color.White.copy(.85f)
            )

            Spacer(modifier = Modifier.height(30.dp))


            // Form card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White.copy(.10f), RoundedCornerShape(22.dp))
                    .padding(26.dp)
            ) {

                Column(horizontalAlignment = Alignment.CenterHorizontally) {

                    // EMAIL
                    OutlinedTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = { Text("Email", fontFamily = poppins, color = Color.White) },
                        leadingIcon = {
                            Icon(Icons.Default.Email, contentDescription = null, tint = Color.White)
                        },
                        singleLine = true,
                        textStyle = TextStyle(color = Color.White, fontFamily = poppins),
                        isError = emailError,
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, Color.White.copy(.4f), RoundedCornerShape(12.dp)),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            cursorColor = Color.White,
                            focusedLabelColor = Color.White
                        )
                    )

                    if (emailError)
                        Text("Invalid email format", color = Color.Yellow, fontFamily = poppins, fontSize = 12.sp)

                    Spacer(modifier = Modifier.height(18.dp))


                    // PASSWORD
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        label = { Text("Password", fontFamily = poppins, color = Color.White) },
                        leadingIcon = {
                            Icon(Icons.Default.Lock, contentDescription = null, tint = Color.White)
                        },
                        trailingIcon = {
                            Icon(
                                imageVector = if (passwordVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.clickable { passwordVisible = !passwordVisible }
                            )
                        },
                        visualTransformation =
                            if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        singleLine = true,
                        textStyle = TextStyle(color = Color.White, fontFamily = poppins),
                        isError = passwordError,
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, Color.White.copy(.4f), RoundedCornerShape(12.dp)),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent,
                            unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            cursorColor = Color.White,
                            focusedLabelColor = Color.White
                        )
                    )

                    if (passwordError)
                        Text("Minimum 6 characters required", color = Color.Yellow, fontFamily = poppins, fontSize = 12.sp)

                    Spacer(modifier = Modifier.height(10.dp))


                    Text(
                        text = "Forgot Password?",
                        fontFamily = poppins,
                        color = Color.White,
                        modifier = Modifier.align(Alignment.End)
                    )
                }
            }


            Spacer(modifier = Modifier.height(20.dp))


            // LOGIN BUTTON
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(55.dp)
                    .clip(RoundedCornerShape(14.dp))
            ) {

                if (!formValid) {
                    Box(
                        modifier = Modifier
                            .offset(x = flashOffset.dp)
                            .fillMaxHeight()
                            .width(120.dp)
                            .background(
                                Brush.horizontalGradient(
                                    listOf(
                                        Color.White.copy(0.1f),
                                        Color.White.copy(0.3f),
                                        Color.White.copy(0.1f)
                                    )
                                )
                            )
                    )
                }


                Button(
                    onClick = {
                        serverMessage = "Logging in..."

                        val call = RetrofitClient.instance.login(
                            email.trim(),
                            password.trim()
                        )

                        call.enqueue(object : retrofit2.Callback<LoginResponse> {

                            override fun onResponse(
                                call: retrofit2.Call<LoginResponse>,
                                response: Response<LoginResponse>
                            ) {
                                val body = response.body()

                                if (body == null) {
                                    serverMessage = "Empty response from server"
                                    return
                                }

                                if (body.status == "success") {
                                    serverMessage = "Login successful!"
                                    navController.navigate("home")
                                } else {
                                    serverMessage = body.message
                                }
                            }

                            override fun onFailure(
                                call: retrofit2.Call<LoginResponse>,
                                t: Throwable
                            ) {
                                serverMessage = "Network error: ${t.message}"
                            }
                        })
                    },
                    enabled = formValid,
                    modifier = Modifier.matchParentSize(),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (formValid) Color.White else Color.White.copy(.4f),
                        disabledContainerColor = Color.White.copy(.3f)
                    )
                ) {
                    Text(
                        "Login",
                        fontFamily = poppins,
                        fontSize = 20.sp,
                        color = if (formValid) Color(0xFF0D1B2A) else Color.Black.copy(.5f)
                    )
                }
            }

                Spacer(modifier = Modifier.height(15.dp))

            Row {
                Text("No account?", color = Color.White, fontFamily = poppins)
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    "Sign Up",
                    color = Color(0xFF00A8E8),
                    fontFamily = poppins,
                    modifier = Modifier.clickable {
                        navController.navigate("register")
                    }
                )
            }
        }
    }
}
